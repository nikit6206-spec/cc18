# CC18 iPad — iOS 18 visual upgrade (0.6.2)

Source base: the provided working CC18iPad tweak. Tuned for iPad 9 (A13), iPadOS 15.x and Dopamine RootHide / arm64e.

## Current scope
- Continuous iOS-18-inspired module corners, with adaptive circular, pill and rounded-rectangle radii.
- Spring press feedback for round controls and module tiles.
- Top-left Add (+) and top-right Power affordances above the CC panel.
- Home grabber/home gesture enablement, optional Dock suppression.
- Dynamic-Island-like screen-recording pill, CFPreferences settings, staged boot-loop protection.

## Important limitation
This is a visual/behavioral restyle of iPadOS 15 Control Center, not a port of the iOS 18 Control Center framework. The iOS 18 edit gallery, drag-and-resize grid, separate native pages (Favorites/Media/Home/Connectivity), and fully reconfigurable control layout depend on newer private system architecture and are not implemented by these styling hooks. Existing iPadOS 15 controls remain underneath.

## Preferences
CFPreferences domain: `com.leha.cc18ipad`.
Keys: `enabled`, `homeBar`, `noDock`, `radius` (8–40), `pressScale` (0.80–1.0), `island`.
Reload: `notifyutil -p com.leha.cc18ipad/ReloadPrefs` or respring.

## Build
Use RootHide Theos, arm64e-capable toolchain, and an iOS 15 SDK:
`make clean package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide`

Boot-loop markers/logs reside under `/var/mobile/Library/Preferences/`.
