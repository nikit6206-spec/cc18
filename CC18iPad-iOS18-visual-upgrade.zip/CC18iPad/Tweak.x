// CC18iPad — iOS 18-style Control Center restyle
// Target: iPad (9th gen, iPad12,1 / iPad12,2) · iPadOS 15.x · rootHide (arm64e)
//
// Safety rules (this dylib lives inside SpringBoard):
//  * only public UIKit/QuartzCore API is called on private views;
//  * private classes are looked up by name at runtime — if one is missing, that
//    part is silently skipped;
//  * deliberately NO blocks, NO @"..."/CFSTR literals and NO own ObjC classes.
//    This build is cross-compiled for arm64e with an upstream clang, and those
//    constructs are where arm64e ABI differences (signed isa / block invoke
//    pointers) would bite. Strings are created at runtime instead;
//  * work is cached and bounded — iPad 9 is a 60 Hz, 3 GB device.

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/utsname.h>

// ------------------------------------------------------------------ logging --
// Diagnostic log: /var/mobile/Library/Preferences/com.leha.cc18ipad.log (capped).

#define CC18_LOGFILE "/var/mobile/Library/Preferences/com.leha.cc18ipad.log"

static void CC18Log(const char *fmt, ...) {
    FILE *f = fopen(CC18_LOGFILE, "a");
    if (!f) return;
    if (ftell(f) > 200 * 1024) { fclose(f); return; }
    va_list ap; va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static int gDumpsLeft   = 0;   // full hierarchy dumps of the overlay
static int gDumpOn      = 0;
#define CC18NS(c) [NSString stringWithUTF8String:(c)]
static void CC18CaptureRP(id obj);
static void CC18DumpMethods(const char *cname, unsigned cap);
static void CC18Fade(CALayer *l, float from, float to, double dur);
static void CC18LogModuleId(UIView *container);
static int gBtnLogs     = 4;
static int gRadiusLogs  = 14;

// ---------------------------------------------------------------- settings --

static BOOL    gEnabled    = YES;
static CGFloat gRadius     = 24.0;   // module corner radius, pt (iPad 9 baseline)
static CGFloat gPressScale = 0.94;   // button press-down scale (iOS 18 feel)
static BOOL    gIsIPad9    = NO;
static BOOL    gHomeBar    = YES;   // force the system home bar + home gesture on
static BOOL    gIsland     = YES;   // recording pill at the top
static BOOL    gNoDock     = YES;   // swipe up = go home, never reveal the Dock
static int     gHomeLogs   = 6;
static int     gDockLogs   = 8;
static int     gModLogs    = 3;

static CFStringRef CC18Str(const char *s) {
    return CFStringCreateWithCString(kCFAllocatorDefault, s, kCFStringEncodingUTF8);
}

static CGFloat CC18PrefFloat(CFStringRef domain, const char *key, CGFloat def, CGFloat lo, CGFloat hi) {
    CGFloat v = def;
    CFStringRef k = CC18Str(key);
    CFPropertyListRef p = CFPreferencesCopyAppValue(k, domain);
    CFRelease(k);
    if (p) {
        if (CFGetTypeID(p) == CFNumberGetTypeID()) {
            double d = 0;
            if (CFNumberGetValue((CFNumberRef)p, kCFNumberDoubleType, &d)) v = (CGFloat)d;
        }
        CFRelease(p);
    }
    return MIN(MAX(v, lo), hi);
}

static void CC18LoadPrefs(void) {
    CFStringRef domain = CC18Str("com.leha.cc18ipad");
    CFPreferencesAppSynchronize(domain);

    gEnabled = YES;
    CFStringRef enKey = CC18Str("enabled");
    CFPropertyListRef en = CFPreferencesCopyAppValue(enKey, domain);
    CFRelease(enKey);
    if (en) {
        if (CFGetTypeID(en) == CFBooleanGetTypeID()) gEnabled = CFBooleanGetValue((CFBooleanRef)en);
        CFRelease(en);
    }

    {
        CFStringRef hk = CC18Str("homeBar");
        CFPropertyListRef hv = CFPreferencesCopyAppValue(hk, domain);
        CFRelease(hk);
        if (hv) {
            if (CFGetTypeID(hv) == CFBooleanGetTypeID()) gHomeBar = CFBooleanGetValue((CFBooleanRef)hv);
            CFRelease(hv);
        }
    }
    {
        CFStringRef dk = CC18Str("noDock");
        CFPropertyListRef dv = CFPreferencesCopyAppValue(dk, domain);
        CFRelease(dk);
        if (dv) {
            if (CFGetTypeID(dv) == CFBooleanGetTypeID()) gNoDock = CFBooleanGetValue((CFBooleanRef)dv);
            CFRelease(dv);
        }
    }
    {
        CFStringRef ik = CC18Str("island");
        CFPropertyListRef iv = CFPreferencesCopyAppValue(ik, domain);
        CFRelease(ik);
        if (iv) {
            if (CFGetTypeID(iv) == CFBooleanGetTypeID()) gIsland = CFBooleanGetValue((CFBooleanRef)iv);
            CFRelease(iv);
        }
    }
    gRadius     = CC18PrefFloat(domain, "radius",     24.0,     8.0,  40.0);
    gPressScale = CC18PrefFloat(domain, "pressScale", 0.94,     0.80, 1.0);
    CFRelease(domain);
}

static void CC18PrefsChanged(CFNotificationCenterRef c, void *o, CFNotificationName n,
                             const void *obj, CFDictionaryRef ui) {
    CC18LoadPrefs();
}

static BOOL CC18DetectIPad9(void) {
    struct utsname u;
    if (uname(&u) != 0) return NO;
    return strcmp(u.machine, "iPad12,1") == 0 || strcmp(u.machine, "iPad12,2") == 0;
}

// ------------------------------------------------------------ class shapes --

@interface CCUIRoundButton : UIControl
@end

@interface CCUIContentModuleContentContainerView : UIView
@end

@interface CCUIButtonModuleView : UIControl
@end

@interface CCUIModuleCollectionViewController : UIViewController
@end

@interface SBFHomeGrabberSettings : NSObject
@end

@interface SBHomeGestureSettings : NSObject
@end

@interface SBHomeGestureDockSwitcherModifier : NSObject
@end

@interface CCUIModularControlCenterOverlayViewController : UIViewController
@end

// ------------------------------------------------------------ view sweeping --

// iOS 18 modules are rounder than iOS 15's fixed 17 pt: radius follows the tile size.
static CGFloat CC18RadiusFor(CGSize sz) {
    // Adaptive silhouette: small square controls become circular; elongated
    // sliders/modules use pill corners; larger square modules use soft continuous corners.
    CGFloat w = MAX(sz.width, 1.0), h = MAX(sz.height, 1.0);
    CGFloat m = MIN(w, h), aspect = MAX(w, h) / m;
    CGFloat scale = gRadius / 24.0;
    if (m <= 72.0) return m * 0.5;
    if (aspect >= 1.45) return MIN(m * 0.48 * scale, m * 0.5);
    CGFloat r = MIN(m * 0.30 * scale, 46.0);
    return MIN(r, m * 0.5);
}

static BOOL CC18IsRoundedChildClass(const char *n) {
    return strcmp(n, "MTMaterialView") == 0 ||
           strcmp(n, "CCUISteppedSliderView") == 0 ||
           strcmp(n, "CCUIContinuousSliderView") == 0;
}

// Restyle the views inside one module's content container that carry the corner radius.
static void CC18StyleChildren(UIView *container, UIView *v, CGFloat r, int depth) {
    if (depth > 3) return;
    NSArray *subs = v.subviews;
    NSUInteger n = subs.count;
    for (NSUInteger i = 0; i < n; i++) {
        UIView *sub = [subs objectAtIndex:i];
        const char *name = class_getName(object_getClass(sub));
        if (CC18IsRoundedChildClass(name)) {
            CGSize a = sub.bounds.size, b = container.bounds.size;
            if (fabs(a.width - b.width) < 2.0 && fabs(a.height - b.height) < 2.0) {
                CALayer *l = sub.layer;
                if (l.cornerRadius != r || l.cornerCurve != kCACornerCurveContinuous) {
                    if (gRadiusLogs > 0) {
                        gRadiusLogs--;
                        CC18Log("style %s %.0fx%.0f r %.1f -> %.1f", name, a.width, a.height, l.cornerRadius, r);
                    }
                    l.cornerCurve = kCACornerCurveContinuous;
                    l.cornerRadius = r;
                    if (strcmp(name, "MTMaterialView") != 0) l.masksToBounds = YES;
                }
            }
        }
        CC18StyleChildren(container, sub, r, depth + 1);
    }
}

static const void *kCC18ClipKey = &kCC18ClipKey;

static void CC18StyleContainer(UIView *container) {
    if (!gEnabled) return;
    CGSize sz = container.bounds.size;
    CGFloat m = MIN(sz.width, sz.height);
    CALayer *cl = container.layer;

    // Expanded / degenerate sizes: release our clip and leave the module alone.
    if (m > 160.0 || m < 20.0) {
        if (objc_getAssociatedObject(container, kCC18ClipKey)) {
            cl.cornerRadius = 0;
            cl.masksToBounds = NO;
            objc_setAssociatedObject(container, kCC18ClipKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        return;
    }

    CGFloat r = CC18RadiusFor(sz);

    // One uniform rounded clip for everything inside the tile (material, media view,
    // sliders), so tiles whose background is not an MTMaterialView match the others.
    if (cl.cornerRadius != r || !cl.masksToBounds || cl.cornerCurve != kCACornerCurveContinuous) {
        cl.cornerCurve = kCACornerCurveContinuous;
        cl.cornerRadius = r;
        cl.masksToBounds = YES;
        objc_setAssociatedObject(container, kCC18ClipKey, [NSNumber numberWithBool:YES], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    CC18StyleChildren(container, container, r, 0);

    // Sibling background view (pressed/highlight state) gets the same radius.
    NSArray *sibs = container.superview.subviews;
    NSUInteger n = sibs.count;
    for (NSUInteger i = 0; i < n; i++) {
        UIView *b = [sibs objectAtIndex:i];
        if (strcmp(class_getName(object_getClass(b)), "CCUIContentModuleBackgroundView") == 0) {
            CALayer *bl = b.layer;
            if (bl.cornerRadius != r) { bl.cornerCurve = kCACornerCurveContinuous; bl.cornerRadius = r; }
        }
    }
}

static UIView *CC18FindAncestor(UIView *v, const char *cls) {
    UIView *p = v.superview;
    for (int i = 0; p && i < 10; i++, p = p.superview)
        if (strcmp(class_getName(object_getClass(p)), cls) == 0) return p;
    return nil;
}

static void CC18SweepView(UIView *v, int depth, int *budget) {
    if (depth > 10 || *budget <= 0) return;
    NSArray *subs = v.subviews;
    NSUInteger n = subs.count;
    for (NSUInteger i = 0; i < n; i++) {
        UIView *sub = [subs objectAtIndex:i];
        if (--(*budget) <= 0) return;

        if (gDumpOn) {
            CGRect b = sub.bounds;
            CC18Log("  d%d %s %.0fx%.0f r=%.1f", depth, class_getName(object_getClass(sub)),
                    b.size.width, b.size.height, sub.layer.cornerRadius);
        }

        if (strcmp(class_getName(object_getClass(sub)), "CCUIContentModuleContentContainerView") == 0)
            { CC18StyleContainer(sub); CC18LogModuleId(sub); }
        CC18SweepView(sub, depth + 1, budget);
    }
}

// --------------------------------------------------------- press animation --

static void CC18AnimateScale(UIView *view, CGFloat to) {
    CALayer *layer = view.layer;
    CGFloat from = 1.0;
    CALayer *pl = layer.presentationLayer;
    if (pl) from = pl.transform.m11;

    CASpringAnimation *a = [CASpringAnimation animationWithKeyPath:[NSString stringWithUTF8String:"transform.scale"]];
    a.fromValue = [NSNumber numberWithDouble:from];
    a.toValue   = [NSNumber numberWithDouble:to];
    a.mass = 1.0;
    a.stiffness = 420.0;
    a.damping = 26.0;
    a.initialVelocity = 0.0;
    a.duration = MIN(a.settlingDuration, 0.45);

    layer.transform = CATransform3DMakeScale(to, to, 1.0);
    [layer addAnimation:a forKey:[NSString stringWithUTF8String:"cc18.press"]];
}

// ------------------------------------------------------------------- hooks --


// ------------------------------------------------- iOS 18 top buttons ("+" / power) --
// iOS 18 puts a "+" (add controls) and a power button above the Control Center panel.
// Built from public UIKit (blur circle + SF Symbol), placed next to the panel.

static int gModIdLogs = 24;

static void CC18LogModuleId(UIView *container) {
    if (gModIdLogs <= 0) return;
    UIResponder *r = container;
    SEL sid = sel_registerName("moduleIdentifier");
    for (int i = 0; r && i < 6; i++) {
        r = [r nextResponder];
        if (r && [r respondsToSelector:sid]) {
            gModIdLogs--;
            id mid = ((id (*)(id, SEL))objc_msgSend)(r, sid);
            CGRect f = container.superview ? [container.superview convertRect:container.frame toView:nil] : container.frame;
            CC18Log("module %s at %.0f,%.0f %.0fx%.0f", [[mid description] UTF8String],
                    f.origin.x, f.origin.y, f.size.width, f.size.height);
            return;
        }
    }
}

static void CC18TopButtonTapped(id self, SEL _cmd, id sender) {
    UITapGestureRecognizer *g = (UITapGestureRecognizer *)sender;
    NSInteger tag = g.view.tag;
    CC18Log("topbutton tapped tag=%d", (int)tag);
    if (tag == 0xCC01) {
        // "+": jump to Settings > Control Center
        NSURL *u = [NSURL URLWithString:CC18NS("prefs:root=CONTROL_CENTER")];
        UIApplication *app = UIApplication.sharedApplication;
        SEL o = sel_registerName("openURL:");
        if (u && [app respondsToSelector:o]) ((BOOL (*)(id, SEL, id))objc_msgSend)(app, o, u);
    } else {
        // power: show the system "slide to power off" screen
        static const char *const holders[] = { "SBPowerDownController", "SBPowerDownViewController", NULL };
        static const char *const singles[] = { "sharedInstance", "sharedController", "shared", NULL };
        static const char *const acts[] = { "activate", "present", "show", "presentPowerDown", "activatePowerDown", NULL };
        BOOL done = NO;
        for (int h = 0; holders[h] && !done; h++) {
            Class c = objc_getClass(holders[h]);
            if (!c) { CC18Log("power: class %s missing", holders[h]); continue; }
            id o = nil;
            for (int k = 0; singles[k] && !o; k++) {
                SEL ss = sel_registerName(singles[k]);
                if ([(id)c respondsToSelector:ss]) o = ((id (*)(id, SEL))objc_msgSend)((id)c, ss);
            }
            if (!o) { CC18Log("power: no shared instance for %s", holders[h]); continue; }
            for (int j = 0; acts[j] && !done; j++) {
                SEL as = sel_registerName(acts[j]);
                if ([o respondsToSelector:as]) {
                    CC18Log("power: calling %s -%s", holders[h], acts[j]);
                    ((void (*)(id, SEL))objc_msgSend)(o, as);
                    done = YES;
                }
            }
        }
        if (!done) {
            CC18Log("power: no way found, dumping PowerDown classes");
            unsigned n = 0;
            Class *list = objc_copyClassList(&n);
            int listed = 0;
            for (unsigned i = 0; list && i < n && listed < 30; i++) {
                const char *nm = class_getName(list[i]);
                if (nm && strstr(nm, "PowerDown") && !strstr(nm, "Accessibility")) { CC18Log("power class: %s", nm); listed++; CC18DumpMethods(nm, 60); }
            }
            free(list);
        }
    }
}

static UIView *CC18FindByClass(UIView *v, const char *cls, int depth) {
    if (depth > 8) return nil;
    if (strcmp(class_getName(object_getClass(v)), cls) == 0) return v;
    for (UIView *sub in v.subviews) {
        UIView *r = CC18FindByClass(sub, cls, depth + 1);
        if (r) return r;
    }
    return nil;
}

static UIView *CC18MakeTopButton(NSInteger tag, const char *symbol, id target) {
    UIVisualEffectView *b = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
    b.frame = CGRectMake(0, 0, 36, 36);
    b.tag = tag;
    b.layer.cornerRadius = 18.0;
    b.clipsToBounds = YES;
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold];
    UIImage *img = [UIImage systemImageNamed:CC18NS(symbol) withConfiguration:cfg];
    UIImageView *iv = [[UIImageView alloc] initWithImage:img];
    iv.tintColor = [UIColor whiteColor];
    iv.contentMode = UIViewContentModeCenter;
    iv.frame = b.bounds;
    [b.contentView addSubview:iv];
    if (target) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:target action:sel_registerName("tapped:")];
        [b addGestureRecognizer:tap];
    }
    return b;
}

static void CC18LayoutTopButtons(UIView *root) {
    UIView *coll = CC18FindByClass(root, "CCUIModuleCollectionView", 0);
    if (!coll || !coll.superview) return;
    UIView *panel = coll.superview;
    CGRect pf = [panel.superview convertRect:panel.frame toView:root];
    if (pf.size.width < 200) return;

    Class tc = objc_getClass("CC18TopTarget");
    if (!tc) {
        tc = objc_allocateClassPair(objc_getClass("NSObject"), "CC18TopTarget", 0);
        if (tc) {
            class_addMethod(tc, sel_registerName("tapped:"), (IMP)CC18TopButtonTapped, "v@:@");
            objc_registerClassPair(tc);
        }
    }
    static id target;
    if (!target && tc) target = [[tc alloc] init];

    UIView *plus = [root viewWithTag:0xCC01];
    UIView *power = [root viewWithTag:0xCC02];
    if (!plus)  { plus  = CC18MakeTopButton(0xCC01, "plus", target);  [root addSubview:plus]; }
    if (!power) { power = CC18MakeTopButton(0xCC02, "power", target); [root addSubview:power]; }

    CGFloat y = pf.origin.y - 46.0;
    if (y < 8.0) y = 8.0;
    plus.frame  = CGRectMake(pf.origin.x + 2.0, y, 36, 36);
    power.frame = CGRectMake(pf.origin.x + pf.size.width - 38.0, y, 36, 36);
    static int lg = 2;
    if (lg > 0) { lg--; CC18Log("topbuttons: panel %.0f,%.0f %.0fx%.0f -> y=%.0f", pf.origin.x, pf.origin.y, pf.size.width, pf.size.height, y); }
}

%group CC18RP

%hook RPControlCenterClient

- (void)updateClientState {
    %orig;
    CC18CaptureRP(self);
}

- (id)init {
    id r = %orig;
    if (r) CC18CaptureRP(r);
    return r;
}

%end

%end // CC18RP

%group CC18Button

%hook CCUIRoundButton

- (void)setHighlighted:(BOOL)highlighted {
    %orig;
    if (!gEnabled) return;
    if (gBtnLogs > 0) { gBtnLogs--; CC18Log("CCUIRoundButton setHighlighted:%d", (int)highlighted); }
    CC18AnimateScale((UIView *)self, highlighted ? gPressScale : 1.0);
}

%end

%end // CC18Button

%group CC18Radius

%hook CCUIContentModuleContentContainerView

- (void)layoutSubviews {
    %orig;
    CC18StyleContainer((UIView *)self);
}

%end

%end // CC18Radius

%group CC18Tile

%hook CCUIButtonModuleView

- (void)setHighlighted:(BOOL)highlighted {
    %orig;
    if (!gEnabled) return;
    UIView *tile = CC18FindAncestor((UIView *)self, "CCUIContentModuleContainerView");
    if (tile) CC18AnimateScale(tile, highlighted ? gPressScale : 1.0);
}

%end

%end // CC18Tile

%group CC18Home

// Make SpringBoard treat this iPad like one without a Home button: the system's own
// home grabber (the bar) and the home gesture (swipe up = home, hold = app switcher).
%hook SBFHomeGrabberSettings

- (BOOL)isEnabled {
    BOOL orig = %orig;
    if (gHomeLogs > 0) { gHomeLogs--; CC18Log("SBFHomeGrabberSettings isEnabled orig=%d", (int)orig); }
    return gHomeBar ? YES : orig;
}

%end

%hook SBHomeGestureSettings

- (BOOL)isHomeGestureEnabled {
    BOOL orig = %orig;
    if (gHomeLogs > 0) { gHomeLogs--; CC18Log("SBHomeGestureSettings isHomeGestureEnabled orig=%d", (int)orig); }
    return gHomeBar ? YES : orig;
}

%end

%end // CC18Home

%group CC18NoDock

// iPad shows the floating Dock for a short swipe-up before it goes home. iPhone-style
// behaviour: the swipe keeps moving the app/home bar and never presents the Dock.
%hook SBHomeGestureSettings

- (double)maximumDistanceYThresholdToPresentDock {
    double orig = %orig;
    if (gDockLogs > 0) { gDockLogs--; CC18Log("maximumDistanceYThresholdToPresentDock orig=%.1f", orig); }
    return gNoDock ? 0.0 : orig;
}

%end

%hook SBHomeGestureDockSwitcherModifier

- (BOOL)_shouldPresentDockForFinalDestination:(NSInteger)destination {
    BOOL orig = %orig(destination);
    if (gDockLogs > 0) { gDockLogs--; CC18Log("shouldPresentDock dest=%ld orig=%d", (long)destination, (int)orig); }
    return gNoDock ? NO : orig;
}

- (BOOL)isCurrentlyTrackingDock {
    return gNoDock ? NO : %orig;
}

- (double)dockProgress {
    return gNoDock ? 0.0 : %orig;
}

%end

%end // CC18NoDock

%group CC18Modules

%hook CCUIModuleCollectionViewController

- (void)viewDidAppear:(BOOL)animated {
    %orig;
    if (gModLogs <= 0) return;
    gModLogs--;
    id r = [(NSObject *)self valueForKey:[NSString stringWithUTF8String:"moduleInstances"]];
    if ([r isKindOfClass:[NSDictionary class]]) {
        NSArray *keys = [(NSDictionary *)r allKeys];
        CC18Log("modules (%lu):", (unsigned long)keys.count);
        for (NSUInteger i = 0; i < keys.count && i < 60; i++)
            CC18Log("  module id: %s", [[[keys objectAtIndex:i] description] UTF8String]);
    } else {
        CC18Log("moduleInstances is %s", r ? class_getName(object_getClass(r)) : "nil");
    }
}

%end

%end // CC18Modules

%group CC18Overlay

%hook CCUIModularControlCenterOverlayViewController

- (void)viewDidLayoutSubviews {
    %orig;
    if (!gEnabled) return;
    int budget = gIsIPad9 ? 400 : 800;
    gDumpOn = (gDumpsLeft > 0);
    if (gDumpOn) { gDumpsLeft--; CC18Log("overlay viewDidLayoutSubviews: hierarchy dump"); }
    CC18SweepView(((UIViewController *)self).view, 0, &budget);
    CC18LayoutTopButtons(((UIViewController *)self).view);
    if (gDumpOn) CC18Log("overlay sweep done, budget left %d", budget);
    gDumpOn = 0;
}

- (void)viewWillAppear:(BOOL)animated {
    %orig;
    if (!gEnabled) return;
    UIView *root = ((UIViewController *)self).view;
    for (int t = 0xCC01; t <= 0xCC02; t++) {
        UIView *b = [root viewWithTag:t];
        if (!b) continue;
        b.hidden = NO;
        b.alpha = 1.0;
        CC18Fade(b.layer, 0.0f, 1.0f, 0.25);
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    %orig;
    UIView *root = ((UIViewController *)self).view;
    for (int t = 0xCC01; t <= 0xCC02; t++) {
        UIView *b = [root viewWithTag:t];
        if (!b) continue;
        b.alpha = 0.0;   // gone at once, not after the panel's dismiss animation
        CC18Fade(b.layer, 1.0f, 0.0f, 0.12);
    }
}

%end

%end // CC18Overlay

// -------------------------------------------------------------------- init --
//
// Boot-loop protection: the constructor drops a ".loading" marker and removes it
// ~12 s later, once SpringBoard has clearly survived. If a marker is still there at
// the next launch, the previous start hung/crashed: the tweak writes ".tripped" and
// stays disabled until that file is deleted. Hooks are installed ~6 s after launch,
// never inside the constructor, and the constructor touches no UIKit.

#define CC18_LOADING "/var/mobile/Library/Preferences/com.leha.cc18ipad.loading"
#define CC18_TRIPPED "/var/mobile/Library/Preferences/com.leha.cc18ipad.tripped"
#define CC18_HOMEOFF "/var/mobile/Library/Preferences/com.leha.cc18ipad.home_off"
#define CC18_RESET   "/var/mobile/Library/Preferences/com.leha.cc18ipad.reset051"

static void CC18Touch(const char *path) {
    int fd = open(path, O_CREAT | O_WRONLY, 0644);
    if (fd >= 0) close(fd);
}

// ------------------------------------------------------------ island (recording) --
//
// Small black pill at the top centre, Dynamic-Island style. Shown while the screen is
// recorded/mirrored (UIScreen.isCaptured): red dot + timer. Tap -> it expands, tap the
// red button -> tries to stop the recording. Public UIKit only, CoreAnimation springs,
// no blocks; the tap target class is created at runtime. A 1 s poll timer drives it.


#define ISL_WIN_W   300.0
#define ISL_WIN_H    90.0
#define ISL_TOP      11.0
#define ISL_CW      132.0
#define ISL_CH       34.0
#define ISL_EW      270.0
#define ISL_EH       62.0

static UIWindow *gIslandWin;
static UIView   *gPill, *gCompact, *gExpandedV;
static UILabel  *gTimeC, *gTimeE;
static id        gIslandTarget;
static BOOL      gIslandExpanded = NO;
static CFAbsoluteTime gRecStart = 0, gExpandedAt = 0;
static int       gIslandLogs = 12;

static void CC18DumpMethods(const char *cname, unsigned cap) {
    Class c = objc_getClass(cname);
    if (!c) { CC18Log("dump: class %s missing", cname); return; }
    unsigned n = 0;
    Method *m = class_copyMethodList(c, &n);
    CC18Log("dump: class %s (%u methods)", cname, n);
    for (unsigned i = 0; m && i < n && i < cap; i++) CC18Log("   - %s", sel_getName(method_getName(m[i])));
    free(m);
}

// Which classes could stop a recording? Logged once per tap on the stop button.
static void CC18DiscoverRP(void) {
    static const char *const subs[] = { "ScreenRecord", "ReplayKit", "RPControlCenter", "RPSystem",
                                        "RPScreenRecorder", "RPBroadcast", "SBRecord", "SBSRecord",
                                        "SBScreenCapture", "ScreenCapture", NULL };
    CC18Log("== discovery RP (isCaptured=%d)", (int)UIScreen.mainScreen.isCaptured);
    unsigned n = 0;
    Class *list = objc_copyClassList(&n);
    int listed = 0;
    for (unsigned i = 0; list && i < n && listed < 50; i++) {
        const char *name = class_getName(list[i]);
        if (!name) continue;
        for (int k = 0; subs[k]; k++) {
            if (strstr(name, subs[k])) {
                CC18Log("name: %s", name);
                listed++;
                if (0) { CC18DumpMethods(name, 60); }
                break;
            }
        }
    }
    free(list);
    static const char *const key[] = { "RPControlCenterClient", "SBRecordingIndicatorManager", "RPControlCenterModule",
        "SADeviceControlStopScreenRecording", "RPScreenRecorder", "SBRecordingIndicatorViewController", NULL };
    for (int k = 0; key[k]; k++) CC18DumpMethods(key[k], 150);
    CC18Log("== discovery RP done (%d names)", listed);
}

static void CC18Spring(CALayer *l, const char *key, id from, id to) {
    CASpringAnimation *a = [CASpringAnimation animationWithKeyPath:CC18NS(key)];
    a.fromValue = from;
    a.toValue = to;
    a.mass = 1.0; a.stiffness = 380.0; a.damping = 24.0; a.initialVelocity = 0.0;
    a.duration = MIN(a.settlingDuration, 0.6);
    [l addAnimation:a forKey:CC18NS(key)];
}

static void CC18Fade(CALayer *l, float from, float to, double dur) {
    CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:CC18NS("opacity")];
    a.fromValue = [NSNumber numberWithFloat:from];
    a.toValue = [NSNumber numberWithFloat:to];
    a.duration = dur;
    [l addAnimation:a forKey:CC18NS("cc18.fade")];
}

static void CC18IslandLayout(BOOL animated) {
    if (!gPill) return;
    BOOL ex = gIslandExpanded;
    CGFloat w = ex ? ISL_EW : ISL_CW, h = ex ? ISL_EH : ISL_CH;
    CGRect nb = CGRectMake(0, 0, w, h);
    CGPoint nc = CGPointMake(ISL_WIN_W / 2.0, ISL_TOP + h / 2.0);
    CGFloat nr = h / 2.0;

    CALayer *l = gPill.layer;
    CALayer *pl = l.presentationLayer;
    CGRect ob = pl ? pl.bounds : l.bounds;
    CGPoint oc = pl ? pl.position : l.position;
    CGFloat orad = pl ? pl.cornerRadius : l.cornerRadius;

    gPill.bounds = nb;
    gPill.center = nc;
    l.cornerRadius = nr;
    gCompact.alpha = ex ? 0.0 : 1.0;
    gExpandedV.alpha = ex ? 1.0 : 0.0;

    if (animated) {
        CC18Spring(l, "bounds", [NSValue valueWithCGRect:ob], [NSValue valueWithCGRect:nb]);
        CC18Spring(l, "position", [NSValue valueWithCGPoint:oc], [NSValue valueWithCGPoint:nc]);
        CC18Spring(l, "cornerRadius", [NSNumber numberWithDouble:orad], [NSNumber numberWithDouble:nr]);
        CC18Fade(gCompact.layer, ex ? 1.0f : 0.0f, ex ? 0.0f : 1.0f, 0.18);
        CC18Fade(gExpandedV.layer, ex ? 0.0f : 1.0f, ex ? 1.0f : 0.0f, 0.22);
    }
}

static void CC18IslandSetExpanded(BOOL ex) {
    gIslandExpanded = ex;
    gExpandedAt = CFAbsoluteTimeGetCurrent();
    CC18IslandLayout(YES);
}

// Stop attempts. A recording made by Control Center lives in replayd, so there is no
// guaranteed public call; try known entry points and always log what exists.
static id CC18Singleton(const char *cname) {
    Class c = objc_getClass(cname);
    if (!c) return nil;
    static const char *const sels[] = { "sharedInstance", "sharedClient", "sharedManager", "sharedRecorder", "shared", "defaultClient", NULL };
    for (int i = 0; sels[i]; i++) {
        SEL sel = sel_registerName(sels[i]);
        if ([(id)c respondsToSelector:sel]) {
            id o = ((id (*)(id, SEL))objc_msgSend)((id)c, sel);
            if (o) { CC18Log("island: %s via +%s", cname, sels[i]); return o; }
        }
    }
    return nil;
}

static void *gRPClient = NULL;   // retained RPControlCenterClient used by the CC record button

static void CC18CaptureRP(id obj) {
    if (gRPClient == (__bridge void *)obj) return;
    if (gRPClient) CFRelease(gRPClient);
    gRPClient = (void *)CFBridgingRetain(obj);
    CC18Log("island: captured RPControlCenterClient %p", gRPClient);
}

static void CC18StopRecording(void) {
    if (gRPClient) {
        id c = (__bridge id)gRPClient;
        SEL st = sel_registerName("stopCurrentSession:");
        SEL on = sel_registerName("recordingOn");
        if ([c respondsToSelector:on]) CC18Log("island: client recordingOn=%d", (int)((BOOL (*)(id, SEL))objc_msgSend)(c, on));
        if ([c respondsToSelector:st]) {
            CC18Log("island: calling RPControlCenterClient -stopCurrentSession:nil");
            ((void (*)(id, SEL, id))objc_msgSend)(c, st, nil);
            return;
        }
    } else {
        CC18Log("island: no captured RPControlCenterClient yet");
    }
    CC18Log("island: stop tapped (isCaptured=%d)", (int)UIScreen.mainScreen.isCaptured);
    static const char *const clss[] = { "RPControlCenterClient", "SBRecordingIndicatorManager", "RPScreenRecorder", NULL };
    static const char *const cands[] = { "stopRecording", "stopRecordingWithHandler:", "stopSystemRecordingWithHandler:",
        "stopScreenRecording", "stopScreenRecordingWithHandler:", "stopRecordingWithCompletionHandler:", "toggleRecording", NULL };
    for (int k = 0; clss[k]; k++) {
        id o = CC18Singleton(clss[k]);
        if (!o) { CC18Log("island: no singleton for %s", clss[k]); continue; }
        for (int j = 0; cands[j]; j++) {
            SEL sel = sel_registerName(cands[j]);
            if (![o respondsToSelector:sel]) continue;
            CC18Log("island: calling %s -%s", clss[k], cands[j]);
            if (strchr(cands[j], ':')) ((void (*)(id, SEL, id))objc_msgSend)(o, sel, nil);
            else ((void (*)(id, SEL))objc_msgSend)(o, sel);
            return;
        }
        CC18Log("island: %s has none of the stop selectors", clss[k]);
    }
    CC18DumpMethods("RPControlCenterClient", 150);
    CC18DumpMethods("SBRecordingIndicatorManager", 150);
}

static void CC18IslandTapped(id self, SEL _cmd, id sender) {
    CC18Log("island: tap received (expanded=%d)", (int)gIslandExpanded);
    UITapGestureRecognizer *g = (UITapGestureRecognizer *)sender;
    CGPoint p = [g locationInView:gPill];
    if (gIslandExpanded) {
        CGRect hit = CGRectMake(ISL_EW - 66.0, 0, 66.0, ISL_EH);
        if (p.x >= hit.origin.x && p.x <= hit.origin.x + hit.size.width && p.y >= hit.origin.y && p.y <= hit.origin.y + hit.size.height) { CC18StopRecording(); CC18IslandSetExpanded(NO); return; }
        CC18IslandSetExpanded(NO);
    } else {
        CC18IslandSetExpanded(YES);
    }
}

static UILabel *CC18Label(CGRect f, CGFloat size, UIFontWeight w, UIColor *c) {
    UILabel *l = [[UILabel alloc] initWithFrame:f];
    l.font = [UIFont monospacedDigitSystemFontOfSize:size weight:w];
    l.textColor = c;
    l.backgroundColor = [UIColor clearColor];
    return l;
}

static UIView *CC18Dot(CGRect f) {
    UIView *d = [[UIView alloc] initWithFrame:f];
    d.backgroundColor = [UIColor systemRedColor];
    d.layer.cornerRadius = f.size.width / 2.0;
    return d;
}

static void CC18IslandBuild(void) {
    if (gIslandWin) return;
    UIWindowScene *scene = nil;
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes) {
        if ([sc isKindOfClass:[UIWindowScene class]]) { scene = (UIWindowScene *)sc; break; }
    }
    CGFloat sw = UIScreen.mainScreen.bounds.size.width;
    CGRect fr = CGRectMake((sw - ISL_WIN_W) / 2.0, 0, ISL_WIN_W, ISL_WIN_H);
    UIWindow *win = scene ? [[UIWindow alloc] initWithWindowScene:scene] : [[UIWindow alloc] initWithFrame:fr];
    win.frame = fr;
    win.windowLevel = UIWindowLevelAlert + 2000.0;
    win.backgroundColor = [UIColor clearColor];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = [UIColor clearColor];
    win.rootViewController = vc;

    Class tc = objc_getClass("CC18IslandTarget");
    if (!tc) {
        tc = objc_allocateClassPair(objc_getClass("NSObject"), "CC18IslandTarget", 0);
        if (tc) {
            class_addMethod(tc, sel_registerName("tapped:"), (IMP)CC18IslandTapped, "v@:@");
            objc_registerClassPair(tc);
        }
    }
    gIslandTarget = tc ? [[tc alloc] init] : nil;

    UIView *pill = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ISL_CW, ISL_CH)];
    pill.backgroundColor = [UIColor blackColor];
    pill.clipsToBounds = YES;
    pill.layer.cornerCurve = kCACornerCurveContinuous;
    [vc.view addSubview:pill];

    // Compact: dot + timer, centred in the small pill.
    UIView *compact = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ISL_CW, ISL_CH)];
    [compact addSubview:CC18Dot(CGRectMake(20, (ISL_CH - 9) / 2.0, 9, 9))];
    UILabel *timeC = CC18Label(CGRectMake(38, 0, 80, ISL_CH), 14, UIFontWeightSemibold, [UIColor whiteColor]);
    timeC.text = CC18NS("0:00");
    [compact addSubview:timeC];

    // Expanded: title + timer, red stop button on the right.
    UIView *expanded = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ISL_EW, ISL_EH)];
    [expanded addSubview:CC18Dot(CGRectMake(22, 17, 9, 9))];
    UILabel *timeE = CC18Label(CGRectMake(40, 9, 120, 22), 16, UIFontWeightSemibold, [UIColor whiteColor]);
    timeE.text = CC18NS("0:00");
    UILabel *sub = CC18Label(CGRectMake(22, 33, 180, 18), 12, UIFontWeightRegular, [UIColor colorWithWhite:0.62 alpha:1.0]);
    sub.text = CC18NS("Запись экрана");
    UIView *stop = [[UIView alloc] initWithFrame:CGRectMake(ISL_EW - 56.0, 11.0, 40.0, 40.0)];
    stop.backgroundColor = [UIColor systemRedColor];
    stop.layer.cornerRadius = 20.0;
    UIView *sq = [[UIView alloc] initWithFrame:CGRectMake(13, 13, 14, 14)];
    sq.backgroundColor = [UIColor whiteColor];
    sq.layer.cornerRadius = 4.0;
    [stop addSubview:sq];
    [expanded addSubview:timeE];
    [expanded addSubview:sub];
    [expanded addSubview:stop];

    [pill addSubview:compact];
    [pill addSubview:expanded];

    if (gIslandTarget) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:gIslandTarget action:sel_registerName("tapped:")];
        [pill addGestureRecognizer:tap];
    }
    gIslandWin = win; gPill = pill; gCompact = compact; gExpandedV = expanded;
    gTimeC = timeC; gTimeE = timeE;
    gIslandExpanded = NO;
    CC18IslandLayout(NO);
    CC18Log("island: built (scene=%d) frame %.0f,%.0f %.0fx%.0f", (int)(scene != nil),
            fr.origin.x, fr.origin.y, fr.size.width, fr.size.height);
}

static void CC18IslandPoll(CFRunLoopTimerRef t, void *info) {
    BOOL cap = gIsland && gEnabled && UIScreen.mainScreen.isCaptured;
    if (gIslandLogs > 0) {
        static int last = -1;
        if (last != (int)cap) { last = (int)cap; gIslandLogs--; CC18Log("island: captured=%d", (int)cap); }
    }
    if (!cap) {
        if (gIslandWin && !gIslandWin.hidden) { gIslandWin.hidden = YES; gIslandExpanded = NO; CC18IslandLayout(NO); CC18Log("island: hidden"); }
        gRecStart = 0;
        return;
    }
    if (!gIslandWin) CC18IslandBuild();
    if (!gIslandWin) return;
    if (gRecStart == 0) gRecStart = CFAbsoluteTimeGetCurrent();
    if (gIslandWin.hidden) {
        gIslandWin.hidden = NO;
        CC18Fade(gPill.layer, 0.0f, 1.0f, 0.25);
        CC18Log("island: shown");
    }
    if (gIslandExpanded && CFAbsoluteTimeGetCurrent() - gExpandedAt > 6.0) CC18IslandSetExpanded(NO);

    int secs = (int)(CFAbsoluteTimeGetCurrent() - gRecStart);
    char buf[24];
    snprintf(buf, sizeof buf, "%d:%02d", secs / 60, secs % 60);
    NSString *txt = CC18NS(buf);
    gTimeC.text = txt;
    gTimeE.text = txt;

    CGFloat sw = UIScreen.mainScreen.bounds.size.width;
    CGFloat x = (sw - ISL_WIN_W) / 2.0;
    if (fabs(gIslandWin.frame.origin.x - x) > 0.5) {
        CGRect f = gIslandWin.frame; f.origin.x = x; f.origin.y = 0; gIslandWin.frame = f;
    }
}

static void CC18Install(CFRunLoopTimerRef t, void *info) {
    CC18LoadPrefs();

    CFStringRef name = CC18Str("com.leha.cc18ipad/ReloadPrefs");
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
                                    CC18PrefsChanged, name, NULL,
                                    CFNotificationSuspensionBehaviorCoalesce);
    CFRelease(name);

    // Each group is installed only if its private class exists on this OS build.
    CC18Log("install: enabled=%d radius=%.1f press=%.2f", (int)gEnabled, gRadius, gPressScale);
    if (objc_getClass("CCUIRoundButton"))                               { %init(CC18Button);  CC18Log("hooked CCUIRoundButton"); }
    else CC18Log("MISSING class CCUIRoundButton");
    if (objc_getClass("CCUIContentModuleContentContainerView"))         { %init(CC18Radius);  CC18Log("hooked CCUIContentModuleContentContainerView"); }
    else CC18Log("MISSING class CCUIContentModuleContentContainerView");
    if (objc_getClass("CCUIModularControlCenterOverlayViewController")) { %init(CC18Overlay); CC18Log("hooked CCUIModularControlCenterOverlayViewController"); }
    else CC18Log("MISSING class CCUIModularControlCenterOverlayViewController");
    {
        Class tc = objc_getClass("CCUIButtonModuleView");
        if (tc && class_getInstanceMethod(tc, sel_registerName("setHighlighted:"))) { %init(CC18Tile); CC18Log("hooked CCUIButtonModuleView"); }
        else CC18Log("CCUIButtonModuleView: no setHighlighted:, tile press skipped");
    }
    if (objc_getClass("CCUIModuleCollectionViewController")) { %init(CC18Modules); CC18Log("hooked CCUIModuleCollectionViewController"); }
    if (objc_getClass("RPControlCenterClient")) { %init(CC18RP); CC18Log("hooked RPControlCenterClient"); }
    {
        CFRunLoopTimerRef poll = CFRunLoopTimerCreate(kCFAllocatorDefault, CFAbsoluteTimeGetCurrent() + 1.0, 1.0, 0, 0, CC18IslandPoll, NULL);
        CFRunLoopAddTimer(CFRunLoopGetMain(), poll, kCFRunLoopCommonModes);
        CC18Log("island: poll armed (enabled=%d)", (int)gIsland);
        CC18DiscoverRP();
    }
}

static void CC18MarkSurvived(CFRunLoopTimerRef t, void *info) {
    unlink(CC18_LOADING);
}

%ctor {
    // Supported: iPadOS 15.x only.
    if (kCFCoreFoundationVersionNumber < 1854.0 || kCFCoreFoundationVersionNumber >= 1900.0) return;

    struct utsname u;
    if (uname(&u) != 0 || strncmp(u.machine, "iPad", 4) != 0) return;
    gIsIPad9 = CC18DetectIPad9();

    // One-time reset per release: old markers must not keep the home bar off forever.
    if (access(CC18_RESET, F_OK) != 0) {
        unlink(CC18_TRIPPED); unlink(CC18_HOMEOFF); unlink(CC18_LOADING);
        CC18Touch(CC18_RESET);
        // The log is capped; start it fresh so new diagnostics are not lost.
        unlink(CC18_LOGFILE);
        CC18Log("ctor: release reset (0.5.1)");
    }
    if (access(CC18_TRIPPED, F_OK) == 0) { CC18Log("ctor: DISABLED, .tripped exists"); return; }
    // Staged recovery. A start that never finished first switches only the home-bar
    // part off (".home_off"); if the next start fails as well, everything is disabled.
    if (access(CC18_LOADING, F_OK) == 0) {
        if (access(CC18_HOMEOFF, F_OK) != 0) {
            CC18Touch(CC18_HOMEOFF);
            CC18Log("ctor: previous start did not finish -> home bar part disabled (.home_off)");
        } else {
            CC18Touch(CC18_TRIPPED);
            unlink(CC18_LOADING);
            CC18Log("ctor: previous start did not finish again -> tripped, tweak disabled");
            return;
        }
    }
    CC18Log("ctor: ok (ipad9=%d)", (int)gIsIPad9);
    CC18Touch(CC18_LOADING);

    // Home bar hooks go in early: SpringBoard reads these settings while it builds its UI.
    if (access(CC18_HOMEOFF, F_OK) != 0 &&
        objc_getClass("SBFHomeGrabberSettings") && objc_getClass("SBHomeGestureSettings")) {
        %init(CC18Home);
        CC18Log("ctor: home bar hooks installed");
        if (objc_getClass("SBHomeGestureDockSwitcherModifier")) {
            %init(CC18NoDock);
            CC18Log("ctor: no-dock hooks installed");
        } else {
            CC18Log("ctor: SBHomeGestureDockSwitcherModifier missing, no-dock skipped");
        }
    } else {
        CC18Log("ctor: home bar hooks skipped");
    }

    CFRunLoopTimerRef install = CFRunLoopTimerCreate(kCFAllocatorDefault,
        CFAbsoluteTimeGetCurrent() + 4.0, 0, 0, 0, CC18Install, NULL);
    CFRunLoopTimerRef survived = CFRunLoopTimerCreate(kCFAllocatorDefault,
        CFAbsoluteTimeGetCurrent() + 7.0, 0, 0, 0, CC18MarkSurvived, NULL);
    CFRunLoopAddTimer(CFRunLoopGetMain(), install,  kCFRunLoopCommonModes);
    CFRunLoopAddTimer(CFRunLoopGetMain(), survived, kCFRunLoopCommonModes);
}
